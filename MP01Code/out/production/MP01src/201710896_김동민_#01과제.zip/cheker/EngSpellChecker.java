package cheker;

public class EngSpellChecker implements ISpellChecker{
    @Override
    public void check() {
        System.out.println("Cheking English Spelling...");
    }
}
