package cheker;

public interface ISpellChecker {
    void check();
}
